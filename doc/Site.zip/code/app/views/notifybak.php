<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta http-equiv="pragma"content="no-cache">
	<title>序列号DSN页面</title>
	<?php if(WEBSITEROOT != '/'){?>
	<link rel="stylesheet" type="text/css" href="<?php echo  WEBSITEROOT;?>app/views/assets/css/index.css"/>
	<?php }else{?>
	<link rel="stylesheet" type="text/css" href="<?php echo  WEBSITEROOT;?>app/views/assets/css/index_wesoft.css"/>
	<?php }?>
</head>
<body>
	<div class="body-div">
		<div class="bodyTitle"><?php if($code === 0){?>Congratulation!<?php }else{?>Registration failed!<?php }?></div>
		<div class="bodyProfile"><?php if($code === 0){?>
		You have finished the registration, please enjoy the new experience with your Thermostat.
		<?php }else{?>
		For some reason, your registration failed. Please make sure the DSN is correct, also your Thermostat is power on and connected to Internet.
		<?php }?>
		</div>
		<div class="emailImg"><img src="<?php echo $imgUrl;?>"></div>
		<div class="finishBtn">
			<a href="<?php echo site_url();?>"><input type="button" class="btn btn-primary btnSet" name="btnSet" value="<?php if($code === 0){?>Finish<?php }else{ echo 'Try again';?><?php }?>"></a>
		</div>
	</div>
</body>
</html>
