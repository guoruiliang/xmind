<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta http-equiv="pragma"content="no-cache">
	<title>序列号DSN页面</title>
	<?php if(WEBSITEROOT != '/'){?>
	<link rel="stylesheet" type="text/css" href="<?php echo  WEBSITEROOT;?>app/views/assets/css/index.css"/>
	<?php }else{?>
	<link rel="stylesheet" type="text/css" href="<?php echo  WEBSITEROOT;?>app/views/assets/css/index_wesoft.css"/>
	<?php }?>
</head>
<body>
	<div class="body-div">
		<div class="bodyTitle">Welcome to Salus</div>
		<div class="bodyProfile">Before you start to use voice control, please complete a few simple steps to register your account and equipment. Let’s get start setting up your new system.
		</div>
		<form action="/setAction" name="deviceForm" id="deviceForm">
		<div>
	<!-- 		<label>请填写设备序列号：</label> -->
			<input class="inputText textDsn" type="text" name="dsn" value=""><br/>
			<input type="button" class="btn btn-primary btnSet" name="btnSet" value="Register">
	<!-- 		<input type="button" name="btnDel" value="删除序列号"> -->
		</div>
		</form>
	</div>
	<script type="text/javascript" src="<?php echo  WEBSITEROOT;?>app/views/assets/js/jquery-1.11.1.js"></script>
	<script type="text/javascript">
	$("#deviceForm").find("input[name='btnSet']").click(function(){
		if($("#deviceForm").find("input[name='dsn']").val()){
			var url = "<?php echo site_url('webservice/requestLwaAuthCode');?>";
			var data = $("#deviceForm").serialize();
			ajaxRequest(url,data,sucessSetfunc);
			}else{
				alert("Please input DSN number of your Thermostat");
			}
	});
	function sucessSetfunc(data){
		if(data.code == 0){
			window.location = data.data;
		}else{
			alert(data.msg);
		}
	}
	function sucessDelfunc(data){
		alert(data.msg);
	}
	function ajaxRequest(url,data,func){
		$.ajax({
			type: "POST",
			url:url,
			data:data,
			dataType:'json',
			success:func,
			error:function(){
				alert("Network error, please try again.");
			}
		});
	}
	</script>
</body>
</html>
