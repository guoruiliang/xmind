<?php
class AM_Controller extends CI_Controller{
	protected $controllerDir = [
			APPPATH.'core'.DIRECTORY_SEPARATOR,
			APPPATH.'controllers/api'.DIRECTORY_SEPARATOR,
			APPPATH.'controllers.DIRECTORY_SEPARATOR'];

	public function __construct(){
		parent::__construct();
		if(isset($this->config->config['websiteRoot'])){
			if($_SERVER['REQUEST_URI']) {
				$url = parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH);
				if(strpos($url, 'code') == 1){
					$websiteRoot = $this->config->config['websiteRootTest'];
				}else{
					$websiteRoot = $this->config->config['websiteRoot'];
				}
			}
			defined("WEBSITEROOT") OR define("WEBSITEROOT", $websiteRoot);
		}else{
			defined("WEBSITEROOT") OR define("WEBSITEROOT",'/');
		}
// 		spl_autoload_register([$this,'autoLoader']);
	}
	public function sendJsonData($data){
		if(isset($data['getJson']) && !empty($data['getJson'])){
			unset($data['getJson']);
			return json_encode($data);
		}
		header('Content-type: application/json');
		echo json_encode($data);exit;
	}
	public function jsonDecode($json, $type = 'array'){
		if($type == 'array'){
			return json_decode($json, true);
		}
		return json_decode($json, false);
	}
// 	public function _remap(){
// 		$URI =& load_class('URI', 'core');
// 		$params = array_slice($URI->rsegments, 2);
// 		call_user_func_array(array(&$CI, $method), $params);
// 	}
}