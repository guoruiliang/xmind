<?php
/*
 * common model
 */
class AM_Model extends CI_Model {
	public $db ;
	public $type;
	public $tablePre;
	public function __construct($params = array()){
		$this->AM_Model($params);
	}
	public function AM_Model($params = array() ){
		$type = '' ;
		$type =( isset($params['type']) && $params['type'] )? $params['type'] : 'default' ;
		parent::__construct();
		$this->db = $this->load->database($type,true);
	}

	//insert one row
	public function insert_one($table,$data){
		log_message("debug", "insert_one: $table");
		$this->db->insert($table,$data) ;
		return array(
			'affect_num'=>$this->db->affected_rows() ,
			'insert_id'=>$this->db->insert_id(),
			'sql'=>$this->db->last_query()
		);
	}

	//update data
	public function updateData($table, $data, $where){
		return $this->db->update($table, $data, $where);
	}
	//search one row
	public function query_one($sql){
		log_message("debug", "query_one: $sql");
		return $this->db->query($sql)->row_array();
	}

	//search rows
	public function query_list($sql){
		log_message("debug", "query_list: $sql");
		$result =array();
		$query = $this->db->query($sql);
		if($query){
			foreach($query->result_array() as $row){
				$result[] = $row ;
			}
		}
		return $result ;
	}

	//get query count
	public function query_count($sql){
		$query = $this->db->query($sql);
		$num_array = $query->result_array();
		$num = 0 ;
		if(isset($num_array[0]) && !empty($num_array[0])){
			foreach ($num_array[0] as $k=>$v){
				$num = $v ;
				break ;
			}
		}
		return $num ;
	}

	//delete data
	public function del_data($sql){
		log_message("debug", "del_data: $sql");
		$query = $this->db->query($sql);
		return $this->db->affected_rows(); //return affected rows

	}

	//update data
	public function update_data($sql){
		log_message("debug", "update_data: $sql");
		$query = $this->db->query($sql);
		return $this->db->affected_rows(); //return affected rows
	}
}
/* End of file TS_Model.php */
/* Location: ./application/core/TS_Model.php */