<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends AM_Controller{

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct(){
		parent::__construct();
		$this->load->model('client_info_model');
	}
	public function index()
	{
		$this->load->view('index');
	}
	public  function sendNumber(){
		$device = $_REQUEST['device'];
		if($device){
			$data = $this->client_info_model->getDevice($device);
			if($data){
				$results = ['response'=>'success','code'=>0,'msg'=>'設置成功'];
				$this->sendJsonData($results);
			}else{
				$results = ['response'=>'error','code'=>1,'msg'=>'設置失敗'];
			}
		}else{
			$results = ['response'=>'error','code'=>2,'msg'=>'请输入DSN'];
		}
		$this->sendJsonData($results);
	}
	public function requestLwaAuthAccessToken(){
		include 'app/controllers/api/Webservice.php';
		$webService = new webService();
		$jsonData = $webService->requestLwaAuthAccessToken();
		$data = $this->jsonDecode($jsonData);
		if($data['code'] === 0){
			$vars = ['sucess' => true];
		}else{
			$vars = ['sucess' => false];
		}
		$this->load->view("success", $vars);
	}
	public function deleteAccesssToken(){
		$this->load->view("delete");
	}
}
