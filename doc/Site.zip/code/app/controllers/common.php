<?php
class common extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct(){
		parent::__construct();
	}
	public function index()
	{
		$comDir = APPPATH.'view/assets';
		$suffix = ['js','css'];
		$request = $_SERVER['REQUEST_URI'];
		$file = str_replace('common/index', '', $request);

		$commPath = APPPATH.'common.php';
		if(file_exists($commPath)){
			include_once $commPath;
		}
		$dirs = '';
		$files = '';
		if(isset($common) && is_array($common)){
			foreach ($common as $key => $c){
				if($key == 'autoLoaderDir'){
					$dirs = $c;
				}else if($key == 'autoLoaderFile'){
					$files = $c;
				}
			}
		}
		if($dirs){
			foreach ($dirs as $dir){
				if(file_exists(APPPATH.$dir)){
					
				}
				$fileContent = file_get_contents(APPPATH);
			}
		}
	}
}