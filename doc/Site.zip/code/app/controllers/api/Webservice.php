<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Webservice extends AM_Controller{
	private $amazonWebsiteConfig = [
			'scope' => 'alexa:all',
			'response_type' => 'code',
			'redirect_uri' => 'http://www.xiposttest.com/webservice/requestLwaAuthAccessToken',
			
	];
	private $testData = [
			'client_id' => 'amzn1.application-oa2-client.8934ee0e055c4c50a4167a7c232c21e9',
			'client_secret' => 'd4094c783664fff2f424482e862b48d406d4ec513ddc4872a5bbcefebda301f7',
			'product_id' =>'TS123456',
			'device_serial_number' =>'123456',
			'scope_data' =>'',
			'state' =>'6042d10f-6bcd-49',
	];
	private $serviceCodePath = 'https://www.amazon.com/ap/oa';
	private $serviceAccessTokenPath = 'https://api.amazon.com/auth/o2/token';
	private $appWebsite = '';
	private $secretKey = 'AM';
	public function __construct(){
		parent::__construct();
		$this->load->model('client_info_model');
		$this->setConfig();
	}
	private function setConfig(){
		if(isset($this->config->config['amazonWebsiteConfig'])){
			$this->amazonWebsiteConfig = $this->config->config['amazonWebsiteConfig'];
		}
	}
	/**
	 * app 保存服務信息
	 */
	public function authDistribution2Web(){
		//請求方式決定
		if(strtoupper($_SERVER['REQUEST_METHOD']) != 'POST'){
			$results = ['response'=>'error','msg'=>'Please use the right method','code'=>1];
			$this->sendJsonData($results);
		}
		$status = true;$param = '';
		$requestData = $_REQUEST;
		//請求數據
		if(!$requestData['client_id']){
			$status = false;
			$param = 'client_id,';
		}
		if(!$requestData['client_secret']){
			$status = false;
			$param .= 'client_secret,';
		}
		if(!$requestData['product_id']){
			$status = false;
			$param .= 'product_id,';
		}
		if(!$requestData['dsn']){
			$status = false;
			$param .= 'dsn,';
		}
		if(!$requestData['mac']){
			$status = false;
			$param .= 'mac,';
		}
		if(!$requestData['redirect_uri']){
			$status = false;
			$param .= 'redirect_uri,';
		}
		//for test
		if($requestData['client_id'] == $this->testData['client_id']){
			$requestData['product_id'] = 'TS123456';
		}
		$param = rtrim($param,',');
		if(!$status){
			$results = ['response'=>'error','msg'=>'The '.$param.' is lost,please send a full parameter','code'=>2];
			$this->sendJsonData($results);
		}
		// 		client_id:amzn1.application-oa2-client.0ac0d1dc03ab404e9437362b41b1a25c
		// 		client_id:amzn1.application-oa2-client.8934ee0e055c4c50a4167a7c232c21e9
		//刪除首尾"'特殊符號
		foreach ($requestData as $key => $value){
			$requestData[$key] = trim($value,"'|\"");
		}
		$deviceData = [
				'client_id' 		=> $requestData['client_id'],
				'client_secret'		=> $requestData['client_secret'],
				'product_id' 		=> $requestData['product_id'],
				'dsn'				=> $requestData['dsn'],
		];
		ksort($deviceData);
		$skey= '';
		foreach ($deviceData as $devs){
			$skey.= $devs;
		}
		$skey = md5($skey);
		if($requestData['secret_key'] != $skey){
			$results = ['response'=>'error','msg'=>'The request parameter is not right','code'=>5];
			$this->sendJsonData($results);
		}
		
		$deviceData['skey'] = $skey;
		$skeyData = $this->client_info_model->getDeviceBySkey($skey);
		if(!empty($skeyData)){//设备在client_id和product_id下已添加
			$results = ['response'=>'error','msg'=>'This device has been existed','code'=>3];
			$this->sendJsonData($results);
		}
		$skeyData = $this->client_info_model->getDevice($requestData['dsn']);
		if(!empty($skeyData)){//设备在client_id和product_id下已添加
			$results = ['response'=>'error','msg'=>'This device has been existed','code'=>3];
			$this->sendJsonData($results);
		}
		$deviceData['mac'] = $requestData['mac'];
		$deviceData['redirect_uri'] = $requestData['redirect_uri'];
		
		$data = $this->client_info_model->saveAuthDistribution2Web($deviceData);
		if($data['insert_id']){
			$results = ['response'=>'success','msg'=>'Adding data sucess','code'=>0];
			$this->sendJsonData($results);
		}
		$results = ['response'=>'error','msg'=>'Adding data fail','code'=>4];
		$this->sendJsonData($results);
	}
	/**
	 * web site 發送DSN獲取亞馬遜的code
	 */
	public function requestLwaAuthCode(){
		$deviceDsn = $_REQUEST['dsn'];//设备号
		if($deviceDsn){
			$deviceData = $this->client_info_model->getDevice($deviceDsn);
		}else{
			$results = ['response'=>'error','code'=>1,'msg'=>'Please input DSN number of your Thermostat'];
			$this->sendJsonData($results);
		}
		if(isset($deviceData) && !empty($deviceData)){
			$scopeData = [
					'alexa:all'=>[
							'productID' => $deviceData['product_id'],
							'productInstanceAttributes' => [
									'deviceSerialNumber' => $deviceData['mac']
							]
					]
			];
			$scopeDataJson = json_encode($scopeData);
			$fields = [
					'client_id' 	=> $deviceData['client_id'],
					'scope' 		=> $this->amazonWebsiteConfig['scope'],
					'scope_data'	=> $scopeDataJson,
					'response_type'	=> $this->amazonWebsiteConfig['response_type'],
					'redirect_uri'	=> $deviceData['redirect_uri'],
					'state'			=> encript($deviceData['dsn'], $this->secretKey)
			];
			$httpUrl = $this->serviceCodePath.'?'.http_build_query($fields);
			$results = ['response'=>'success','code'=>0,'msg'=>'Setting device number success','data'=>$httpUrl];
			$this->sendJsonData($results);
		}
		$results = ['response'=>'error','code'=>2,'msg'=>'Please make sure the DSN is correct, also your Thermostat is power on and connected to Internet.'];
		$this->sendJsonData($results);
	}
	/**
	 * 獲取access token
	 */
	public function requestLwaAuthAccessToken(){
		//code
		//https://www.baidu.com/?code=ANyEbMOoEUEsiyMctkaw&scope=alexa%3Aall
		//token
		//$url = 'https://www.baidu.com/#access_token=Atza%7CIwEBILKV84J7Mdn8pfpqIOkpfCT9LLYYzG7C_UdM-8x3CnYGO6wPXJErQsjdT1ltIBxlV3c99AmFdlplrnpd2vqeGi4pIrN7VYYUQDttQGyOwPCoAPlVDT32aPSHlPbqNhMg7eN2_qJZa0K8vud6mD51jpzc_8jsaQn1ZqwDi9UzNbsXmkw0U2bP-XZXExCgDN3HuXCzEpA1JmuVKsDL2KaAwPj_VBdYSvSQlqHMPsJxQffNPqb6g99WLqBFV7S43IIbEF91xBMNrVzU2Ey4r7N6w3iY6C3swpnrNXlxoTG5PAnoFBh8_vmNg1XrQmB40JB3YYARfE4CdURaC6JEchidHE2nMBAgiM0tr5qkLsHVaFLMpL14HYSQZV6_4ts1OMFuAtzs_RcAaUFa_zZ4rJNCFjQf5bt3NzXGDwgQMjWS7Blm0eorjbKESrlZ3LOPdSSa0SR19e-cosARo66VYuS3m8Ws7wy0Z8WTGlc9LrOPbLarLo_IaeyV9dy67tY5qMXXQ5aFjfJKO5tlrr5WTHNoll51&token_type=bearer&expires_in=3600&scope=alexa%3Aall';
		$amazonCode = $_REQUEST['code'];
		$deviceDsn = $_REQUEST['state'];
		$amazonError = $_REQUEST['error'];
		//$amazonCode = 'ANXXDbsZUsqlWrQaiSHn';
		$deviceDsn= decript($deviceDsn,$this->secretKey);
		//$device = '123456';
		
		//防止重複請求
		if($amazonCode && $deviceDsn){
			$deviceData = $this->client_info_model->getDevice($deviceDsn);
			if($deviceData){
				$code = $this->client_info_model->getCode($deviceDsn, $amazonCode);
				if($code){
					$results = ['code' => 0];
					$results['imgUrl'] = WEBSITEROOT.'app/views/assets/img/validation_completed.png';
					$this->load->view("notify", $results);
					return '';
				}
			}
		}else{
			header('Location:'.WEBSITEROOT);
		}

		$status = true;
		if(!$amazonCode || $amazonError){
			$results = ['response'=>'error','code'=>1,'msg'=>'The code is empty'];
			$status = false;
		}
		if(!$deviceDsn){
			$results = ['response'=> 'error','code'=>2, 'msg'=>'Please write down the device number'];
			$status = false;
		}
		if($status){
			$deviceData = $this->client_info_model->getDevice($deviceDsn);
			if(isset($deviceData) && !empty($deviceData)){//查詢到为空
				$headers = ['Content-Type:application/x-www-form-urlencoded','charset=UTF-8'];
				$body   = [
						'grant_type' 	=> 'authorization_code',
						'code'			=> $amazonCode,
						'client_id'		=> $deviceData['client_id'],
						'client_secret'	=> $deviceData['client_secret'],
						'redirect_uri'	=> $deviceData['redirect_uri']
				];
				$data = [
						'type' 		=> 'post',
						'is_safety' => true,
						'postData' 	=> $body,
						'headers'	=> $headers,
						'url'		=> $this->serviceAccessTokenPath
				];
				
				$returnAccessJson = sendCurlCode($data);//返回jison数据
				$returnAccess = json_decode($returnAccessJson, true);
				if(isset($returnAccess['error'])){
					$results = ['response'=>'error','code'=>4,'msg'=>'The code has been expired.Please reapply the code again'];
				}else if(isset($returnAccess['access_token'])){
					$saveData = ['dsn' => $deviceDsn];
					$saveData = array_merge($saveData,$returnAccess);
					$this->deleteOldAccessToken($deviceDsn);
					$results = $this->saveAuthAccessToken($saveData);
					$this->client_info_model->setCode($amazonCode,$deviceDsn);
				}
			}else{
				$results = ['response'=>'error','code'=>3,'msg'=>'Please open the app dsn device first'];
			}
		}
// 		if($results['code'] == 0){
//		$results['imgUrl'] = WEBSITEROOT.'app/views/assets/img/validation_completed.png';
// 		}else{
// 			$results['imgUrl'] = WEBSITEROOT.'app/views/assets/img/validation_fails.png';
// 		}
		$results['imgUrl'] = WEBSITEROOT.'app/views/assets/img/validation_completed.png';
		$this->load->view("notify", $results);
	}
	//保存accesstoken 到數據庫中
	protected function saveAuthAccessToken($saveData){
		if(!empty($saveData)){
			$data = [
					'dsn' 			=> $saveData['dsn'],
					'access_token'	=> $saveData['access_token'],
					'refresh_token'	=> $saveData['refresh_token'],
					'token_type'	=> $saveData['token_type'],
					'expires_in'	=> $saveData['expires_in'],
					'write_time'	=> time(),
					'is_deleted'	=> 0,
			];
			$returnData = $this->client_info_model->insertOneAuthData($data);
			if($returnData['affect_num'] > 0){
				return ['response'=>'success','code'=>0,'msg'=>'Adding the access token success'];
			}else{
				return ['response'=>'error','code'=>5,'msg'=>'Adding the access token fail'];
			}
		}
	}
	public function getAccessToken(){
		$deviceDsn = $_REQUEST['dsn'];
		//驗證device存在性
		if($deviceDsn){
			$result = $this->client_info_model->getDevice($deviceDsn);
		}
		else{
			$result = false;
			$results= ['response'=>'error','code'=>3,'msg'=>'Please add parameter dsn'];
			$this->sendJsonData($results);
		}
		if(!$result){
			$results= ['response'=>'error','code'=>2,'msg'=>'This device did not exist'];
			$this->sendJsonData($results);
		}
		$result = $this->client_info_model->getAccessToken($deviceDsn);
		if(empty($result)){
			$results= ['response'=>'success','code'=>1,'msg'=>'This device has no token,pelease go to device setting.'];
		}else{
			$results= ['response'=>'success','code'=>0,'msg'=>'Getting token successfully','data' => $result];
		}
		$this->sendJsonData($results);
	}
	//just for a test
	public function refreshAccessToken(){
		//https://api.amazon.com/auth/o2/token?
		//grant_type=refresh_token&refresh_token=Atzr|IwEBIPbnbSdKj8DgcB_uF13Wfoq-uxp-iyM3mlW9CvNEyXCCvVQlNPuuuxa3mygt16PrX2DTSutGr18wO8cELt6kNrz2DoqxOpv1x4JhGTGgz1XcsPHODfrc3KcG1n_KUpbQHwts0ieCyuiwGZprLPZyP-DPGL_IAjJCcQkoBaYj9ZdjRS_YUrzWQ1_qDAEFgzaQF9Q_joCKyxmEX4UV1WitktoIbs_XUvlzJHlQvh6hG2lurDbwiUYHK4Xz2tewIew3nJqMwCVAzTAbfpTKzyxbqoVHzd6uP3XU4gTw95Tr_hYAoCiuKWk6kcwhlWARi3gvjR5AHFLDTyjAjAoZzutEMS-aNy5FCANRFUmCkguDMRdThJ5cwhYe_cx7wNut9gBlBZGBeR1eIQtHD0lI139EceWhKV4tG4uou69NpUBJXYsg_Jqk78gtrcn10Ya1t_GmfRvOIRe9qIZ26pzeJu3P_RKwZCwslc79saQ0vMmJjSIsWwh3CV4Slkv1CMOA4ebCvnyUZJzPZr4Oicmu-G2Bc6Nn&
		//client_id=amzn1.application-oa2-client.8934ee0e055c4c50a4167a7c232c21e9&client_secret=d4094c783664fff2f424482e862b48d406d4ec513ddc4872a5bbcefebda301f7
		$deviceDsn = '123456';
		$deviceData = $this->client_info_model->getDevice($deviceDsn);
		$skey = '';
		echo "<pre>";
		//$this->serviceAccessTokenPath = 'http://www.baidu.com';
		if(isset($deviceData) && !empty($deviceData)){//查詢到位空
			$result = $this->client_info_model->getAccessToken($deviceDsn);
			if(is_array($result) && count($result) > 0){
				$result = $result[0];
				print_r($result);
				$headers = ['Content-Type:application/x-www-form-urlencoded','charset=UTF-8'];
				$body = [
						'grant_type' 	=> 'refresh_token',
						'client_id'		=> $deviceData['client_id'].$skey,
						'client_secret'	=> $deviceData['client_secret'].$skey,
						'refresh_token'	=> $result['refresh_token'],
				];
				$data = [
						'type' 		=> 'post',
						'is_safety' => true,
						'postData' 	=> $body,
						'headers'	=> $headers,
						'url'		=> $this->serviceAccessTokenPath
				];
				$returnAccessJson = sendCurlCode($data);//返回jison数据
				$returnAccess = json_decode($returnAccessJson, true);
				print_r($returnAccess);
				if($result['refresh_token'] == $returnAccess['refresh_token']){
					echo "refresh_token is the same";
				}
				if($result['access_token'] == $returnAccess['access_token']){
					echo "access_token is the same";
				}
			}else{
				exit("ss");
			}
		}
	}
	public function deleteOldAccessToken($dsn = ''){
		$deviceDsn = !empty($dsn)?$dsn:$_REQUEST['dsn'];
		if($deviceDsn){
			$this->client_info_model->deleteCode($deviceDsn);
			$res = $this->client_info_model->deleteAccesssTokenByDsn($deviceDsn);
			if($res){
				$results = ['response'=>'success','code'=>0,'msg'=>'Deleting access token success'];
			}else{
				$results = ['response'=>'error','code'=>1,'msg'=>'Deleting access token fail'];
			}
		}else{
			$results = ['response'=>'error','code'=>2,'msg'=>'Please input DSN number'];
		}
		if(!empty($dsn)) $results['getJson'] = true;
		return $this->sendJsonData($results);
	}
	public function index(){
		echo json_encode(['response'=>'error','code'=>0,'msg'=>'Please access valid url link']);
	}
}
