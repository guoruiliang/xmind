<?php
function routerRlue(){
// 	$router = & load_class('Router', 'Core');
// 	$router->fetch_directory();
}