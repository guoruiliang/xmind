<?php
/**
 * 字符串加密
 * @param unknown $string
 * @param string $key
 * @return string
 */
function encript($string,$key = ''){
	$encrypt = new CI_Encrypt();
	return $encrypt->encode($string,$key);
}
/**
 * 字符串解密
 * @param unknown $string
 * @param string $key
 * @return string
 */
function decript($string,$key = ''){
	$encrypt = new CI_Encrypt();
	return $encrypt->decode($string, $key);
}
/**
 * file_get_content 發送http請求
 * @param unknown $url
 * @param unknown $data
 * @param string $type
 * @return string
 */
function sendhttpRequestCode($url, $data, $type = 'GET'){
	$data = http_build_query($data);  //把参数转换成URL数据
	$type = strtoupper($type);
	ini_set('user_agent','Mozilla/4.0 (compatible; MSIE 5.00; Windows 98)');
	$aContext = array(
		'http' => array(
				'method' => $type,
				'header'  => 'Content-type: application/x-www-form-urlencoded',
				'content' => $data,
				'timeout' => 20
		)
	);
	$cxContext  = stream_context_create($aContext);
	return file_get_contents($url,false,$cxContext);
}
/**
 * curl發送http請求
 * @param unknown $data
 * @return mixed
 */
function sendCurlCode($data){
	$curl = curl_init(); // 启动一个CURL会话
	curl_setopt($curl, CURLOPT_URL, $data['url']);
	curl_setopt($curl, CURLOPT_HEADER, 0);//是否輸出頭信息
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);//返回結構
	if(isset($data['headers']) && !empty($data['headers'])){
		curl_setopt($curl, CURLOPT_HTTPHEADER, $data['headers']);//設置頭信息
	}
	if(isset($data['is_safety']) && !empty($data['is_safety'])){//https請求
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false); // 跳过证书检查
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 2);  // 从证书中检查SSL加密算法是否存在
	}
	if(isset($data['port']) && !empty($data['port'])){
		curl_setopt($curl, CURLOPT_PORT, $data['port']);  // 設置端口
	}
	if (isset($data['type']) && strtoupper($data['type']) == 'POST'){
		curl_setopt($curl, CURLOPT_POST, true);
	}
	if(isset($data['postData']) && !empty($data['postData'])){
		curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data['postData']));
	}
	$curlRes = curl_exec($curl);     //返回api的json对象
	//关闭URL请求
	curl_close($curl);
	return $curlRes;    //返回json对象
}