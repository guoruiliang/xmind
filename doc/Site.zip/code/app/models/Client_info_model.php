<?php
class Client_info_model extends AM_Model{
	public function __construct(){
		parent::__construct();
		$this->tablePre = $this->db->dbprefix;
	}
	public function getDevice($device){
		$sql = "SELECT * FROM ".$this->tablePre."device WHERE dsn=?";
		return $this->db->query($sql, $device)->row_array();
	}
	public function getDeviceBySkey($skey){
		$sql = "SELECT * FROM ".$this->tablePre."device WHERE skey=?";
		return $this->db->query($sql, $skey)->row_array();
	}
	public function saveAuthDistribution2Web($deviceData){
		$table = $this->tablePre.'device';
		return $this->insert_one($table, $deviceData);
	}
	public function insertOneAuthData($data){
		$table = $this->tablePre.'authrization';
		return $this->insert_one($table, $data);
	}
	public function deleteAccesssTokenByDsn($dsn){
		$table = $this->tablePre.'authrization';
		$deviceData = ['is_deleted' => 1, 'deleted_time' => time()];
		$dsnData = ['dsn' => $dsn, 'is_deleted' => 0];
		return $this->updateData($table, $deviceData, $dsnData);
	}
	public function getAccessToken($dsn){
		$table = $this->tablePre.'authrization';
		$dsnData = ['dsn' => $dsn, 'is_deleted' => 0];
		return $this->db->where($dsnData,'',TRUE)->get($table)->result_array();
	}
	public function getCode($dsn, $code){
		$table = $this->tablePre.'code';
		$codeData = ['dsn' => $dsn, 'code' => $code, 'deleted' => 0];
		return $this->db->where($codeData,'',TRUE)->get($table)->result_array();
	}
	public function deleteCode($dsn){
		$table = $this->tablePre.'code';
		$deviceData = ['deleted' => 1, 'deleted_time' => time()];
		$dsnData = ['dsn' => $dsn, 'deleted' => 0];
		return $this->updateData($table, $deviceData, $dsnData);
	}
	public function setCode($code,$dsn){
		$table = $this->tablePre.'code';
		$codeData = ['code' => $code,'dsn'=>$dsn];
		return $this->insert_one($table, $codeData);
	}
}