/*
Navicat MySQL Data Transfer

Source Server         : 127.0.0.1:3306
Source Server Version : 50505
Source Host           : 127.0.0.1:3306
Source Database       : composite

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2017-10-09 09:28:04
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `am_authrization`
-- ----------------------------
DROP TABLE IF EXISTS `am_authrization`;
CREATE TABLE `am_authrization` (
  `dsn` char(30) NOT NULL,
  `access_token` text NOT NULL,
  `refresh_token` text NOT NULL,
  `token_type` char(20) NOT NULL,
  `expires_in` mediumint(4) NOT NULL,
  `write_time` int(11) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `deleted_time` int(11) NOT NULL DEFAULT '0',
  KEY `index` (`dsn`,`is_deleted`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of am_authrization
-- ----------------------------

-- ----------------------------
-- Table structure for `am_code`
-- ----------------------------
DROP TABLE IF EXISTS `am_code`;
CREATE TABLE `am_code` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(50) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `deleted_time` int(11) DEFAULT NULL,
  `dsn` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`) USING BTREE,
  KEY `dsn` (`dsn`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of am_code
-- ----------------------------

-- ----------------------------
-- Table structure for `am_device`
-- ----------------------------
DROP TABLE IF EXISTS `am_device`;
CREATE TABLE `am_device` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` varchar(100) NOT NULL,
  `client_secret` varchar(100) NOT NULL,
  `product_id` varchar(30) NOT NULL,
  `dsn` varchar(30) NOT NULL,
  `skey` char(32) NOT NULL,
  `mac` char(20) NOT NULL,
  `redirect_uri` varchar(500) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `dsn` (`dsn`) USING BTREE,
  UNIQUE KEY `skey` (`skey`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of am_device
-- ----------------------------
